SuperHud Editor v0.3.0
-----------------------------------------------------------------------------
-1- Introduction
-2- Using SuperHud Editor
-3- Config file
-4- Images/Fonts from pk3 files
-5- SuperHud
-6- Bugs
-7- Updating
-7- Contact
-8- Links
-----------------------------------------------------------------------------

-1- INTRODUCTION
SuperHud Editor gives you a graphical interface to edit your HUD 
(Head-up display) for CPMA [1] (a Quake3 modification) and possibly other 
First-person shooter games in the future.


-2- USING SUPERHUD EDITOR
You start with a default HUD supplied by CPMA. Other HUDs are placed in 
<quake3dir>/cpma/hud/
Make sure you save it to that directory. Otherwise you cannot use
them ingame.

To tell cpma which hudfile you want to use set the cvar ch_file to
the name of the hud (without the extension .cfg).
For example if you want to use hud3.cfg, put in <quake3dir>/cpma/autoexec.cfg 

  seta ch_file "hud3"

The GUI should be more or less self explanatory, check the ChangeLog for
a few features to look out for.

  
-3- CONFIG FILE
Will be automatically created at

(Windows) 
    C:\Documents and Settings\<username>\Application Data\q3cpmahudeditor\superhudeditor.conf
(Linux)   
  ~/.superhudeditor/superhudeditor.conf


-4- IMAGES/FONTS FROM PK3 FILES
In hud elements you may also specify which image to draw as background.
Those are taken from the paks the game provides which are normally not
subject to change but restricted which ones you can use. That restriction
depends on the server you are on, you can only pick images from paks the
server has.
Hence you should (normally) stick to those images that are in paks which are
on _all_ servers. The pak browser only presents you those available files.
A missing image (or from a non-standard pak) will be displayed as big red 
cross.
  

-5- SUPERHUD
A (mostly) complete documentation about SuperHud files can be found
at the cpma wiki [2].


-6- BUGS
Known bugs can be found in the source distribution in file KNOWNBUGS
Limitations of SuperHud itself can be read at [3].

If drag&drop is laggy you might add the following in the configfile (see -3-)

  view_updatewhiledragging=false


-7- UPDATING
By default, at each start the app checks in the background if a new version 
is available and prompts you what to do if it found an update. 
SuperHud Editor now features a Web Updater which takes care of updating, no
need to download and install the new version. At least on windows. For linux
this feature is disabled as it probably requires superuser access with the 
default installation routine. A notifcation about new versions is displayed 
nevertheless.


-8- CONTACT
Check the app's website [4] for news&updates or make sure you enable the
startup check for new versions (Tools->Preferences|Network)

You might also contact me on irc [5] or send me an e-mail [6].
Feel free to post in the forums on sourceforge [7].


-9- LINKS

[1] http://www.promode.org
[2] http://www.promode.org/wiki/index.php/Custom_HUDs
[3] http://www.promode.org/wiki/index.php/Custom_HUDs#Known_Issues
[4] http://plrf.org/superhudeditor
[5] #promode on irc.quakenet.org
[6] rolansch@ethz.ch
[7] http://sourceforge.net/projects/superhudeditor

